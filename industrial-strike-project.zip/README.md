# Industrial Strike

Mobile-first 3D FPS prototype for Android, built with Godot 4.7.2.

## Prototype features
- First-person movement and camera
- Touch controls: left side to move, right side to look
- Fire and jump buttons
- Procedurally built abandoned industrial yard
- Four practice targets and a hit counter
- Mobile renderer, landscape orientation, ARM64 APK

This is the first playable foundation, not yet an online multiplayer game. Networked matches, authoritative server logic, weapons, animations, sound and production assets will be added in later stages.

Target device: iQOO Z10, 12 GB RAM, 60 FPS target. Performance must be measured on-device.
