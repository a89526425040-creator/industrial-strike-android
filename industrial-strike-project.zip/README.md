# Industrial Strike

Mobile-first 3D FPS prototype for Android, built with Godot 4.7.2.

## Current features
- First-person movement and camera
- Touch controls: left side to move, right side to look
- Fire, automatic fire, reload and jump buttons
- Procedurally built abandoned industrial yard
- Four practice targets with shared health in online matches
- Visible M16A1 model and recoil animation
- Landscape/portrait switch
- Android ARM64 export, Compatibility renderer

## Two-player online prototype
The project now includes a basic ENet client-host multiplayer mode:
- One device presses **HOST**.
- The second device enters the host IP and presses **JOIN**.
- Both players see each other's player avatar and movement.
- Target hit registration and target health are handled by the host and synchronized.
- Maximum match size is two players total (host + one client).
- Network transport: ENet over UDP port **24567**.

### Connection notes
For a first test, connect both phones to the same Wi-Fi and use the LAN IP shown by the host in the network status text. For internet play across different networks, the host needs a publicly reachable UDP port 24567 (router port forwarding and a public IP). Mobile carrier networks often use CGNAT, which prevents direct inbound connections. This prototype does not yet include matchmaking, a cloud relay, accounts, or a dedicated server.

This is an early networking milestone, not a production-ready competitive FPS. Movement is sent at 20 updates/second; interpolation and server-side target hit registration are basic. Latency, prediction, lag compensation, reconnect handling, player health/death, and security hardening remain future work.

## Target device
iQOO Z10, 12 GB RAM, 60 FPS target. Performance and multiplayer behavior must be measured on real devices.

## Build
Open the project in Godot 4.7.2 and export using the Android preset. The GitHub Actions workflow in the repository can also build the APK from the project archive.
