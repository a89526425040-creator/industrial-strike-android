Industrial Strike — imported M16A1 asset

The weapon is now a separate GLB 3D asset at assets/weapons/m16a1_classic.glb.
It contains independent PBR mesh parts (receiver, classic carry handle, fixed stock, ribbed handguard, barrel, front sight, flash suppressor, magazine, grip, trigger and pins).
The main Godot script instances the GLB scene and retains the existing firing recoil animation.

Open the project in Godot 4.x. The GLB is imported by Godot on first project scan.
