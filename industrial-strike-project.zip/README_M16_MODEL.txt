M16A1 FIRST-PERSON WEAPON MODEL

The previous block-built placeholder weapon has been replaced with the user-provided
M16A1 GLB model.

Integration:
- Loaded by scripts/main.gd as res://assets/weapons/m16a1_classic.glb
- Kept the existing first-person weapon mount and recoil behavior.
- Textures were reduced from 4096x4096 to 2048x2048 for a more practical Android
  memory and package-size footprint. Base-color textures use JPEG; normal and
  metallic/roughness textures remain PNG.
- Model geometry and scene hierarchy were preserved.

Source attribution (as provided with the model):
M16A1 by SeveN, Sketchfab:
https://sketchfab.com/3d-models/m16a1-a27a642fea8c465a910ee5b6df0efd85
Creative Commons Attribution (CC BY). Retain this credit when redistributing
the asset; verify the exact license terms on the source page.

Note: the project archive and GLB structure were validated locally. A Godot/Android
export was not run in this environment.
