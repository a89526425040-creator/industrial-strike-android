Industrial Strike - Classic M16 update

Replaced the temporary blocky rifle placeholder with a recognizable classic M16A1-style first-person model assembled from separate low-poly Godot 3D parts:
- fixed stock and butt plate
- carry handle and rear aperture sight
- ribbed handguard
- front sight post and protective ears
- long barrel and flash suppressor
- receiver, magazine, pistol grip, trigger guard and controls

Existing firing/recoil/ammo logic is retained. This is a procedural in-engine model, not an imported high-detail PBR asset. It has not yet been opened in Godot or tested on-device in this environment.
