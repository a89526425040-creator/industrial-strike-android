extends Node3D

const PLAYER_SPEED := 7.0
const MOUSE_SENSITIVITY := 0.0022
const TOUCH_SENSITIVITY := 0.004
const GRAVITY := 22.0
const MAGAZINE_SIZE := 30
const START_RESERVE_AMMO := 90
const SHOT_DAMAGE := 34
const SHOT_INTERVAL := 0.18
const RELOAD_SECONDS := 1.35

var player: CharacterBody3D
var camera: Camera3D
var pitch := 0.0
var touch_move := Vector2.ZERO
var look_touch_id := -1
var move_touch_id := -1
var last_look_position := Vector2.ZERO
var targets_destroyed := 0
var total_targets := 4
var ammo_in_magazine := MAGAZINE_SIZE
var reserve_ammo := START_RESERVE_AMMO
var health := 100
var shot_cooldown := 0.0
var reloading := false
var firing := false
var weapon_root: Node3D
var weapon_recoil := 0.0
var is_landscape := true
var hud_label: Label
var ammo_label: Label
var health_label: Label
var message_label: Label

func _ready() -> void:
	_build_world()
	_build_player()
	_build_hud()
	_update_hud()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_world() -> void:
	var world_env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.12, 0.18, 0.23)
	sky_material.sky_horizon_color = Color(0.55, 0.48, 0.37)
	sky_material.ground_bottom_color = Color(0.10, 0.11, 0.10)
	sky_material.ground_horizon_color = Color(0.28, 0.25, 0.20)
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.48, 0.52, 0.55)
	environment.ambient_light_energy = 0.55
	world_env.environment = environment
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)

	_add_box("Concrete yard", Vector3(0, -0.5, 0), Vector3(72, 1, 72), Color(0.24, 0.25, 0.23))
	_add_box("Main factory", Vector3(0, 5, -22), Vector3(34, 10, 12), Color(0.31, 0.32, 0.29))
	_add_box("Left warehouse", Vector3(-23, 4, -5), Vector3(12, 8, 28), Color(0.25, 0.29, 0.28))
	_add_box("Right warehouse", Vector3(23, 4, -7), Vector3(12, 8, 24), Color(0.32, 0.29, 0.24))
	_add_box("Loading bay", Vector3(0, 2.5, 9), Vector3(22, 5, 5), Color(0.30, 0.28, 0.23))

	for i in range(5):
		_add_box("Roof vent", Vector3(-12 + i * 6, 10.8, -22), Vector3(1.8, 1.6, 2.0), Color(0.19, 0.22, 0.22))
	for i in range(7):
		_add_box("Cargo container", Vector3(-13 + i * 4.3, 1.3, 2.0), Vector3(3.6, 2.6, 2.8), Color(0.36, 0.24 + float(i % 2) * 0.04, 0.13))
	_add_box("Concrete barrier", Vector3(0, 0.8, 16), Vector3(14, 1.6, 1.2), Color(0.48, 0.43, 0.32))
	_add_box("Pipe stack", Vector3(-17, 1.2, 17), Vector3(5, 2.4, 3), Color(0.20, 0.25, 0.25))
	_add_box("Generator", Vector3(16, 1.2, 17), Vector3(4, 2.4, 3), Color(0.20, 0.24, 0.19))

	for i in range(total_targets):
		_add_target(Vector3(-9 + i * 6, 1.15, -8))

func _add_box(label_text: String, position: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.name = label_text
	body.position = position
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.88
	mesh_instance.material_override = material
	body.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)

func _add_target(position: Vector3) -> void:
	var target := StaticBody3D.new()
	target.name = "PracticeTarget"
	target.position = position
	target.set_meta("is_target", true)
	target.set_meta("health", 100)
	var mesh_instance := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.48
	mesh.bottom_radius = 0.48
	mesh.height = 1.8
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.72, 0.18, 0.10)
	material.metallic = 0.15
	mesh_instance.material_override = material
	target.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 0.48
	shape.height = 1.8
	collision.shape = shape
	target.add_child(collision)
	add_child(target)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 1.2, 24)
	var capsule := CollisionShape3D.new()
	var capsule_shape := CapsuleShape3D.new()
	capsule_shape.radius = 0.38
	capsule_shape.height = 1.8
	capsule.shape = capsule_shape
	capsule.position.y = 0.9
	player.add_child(capsule)

	camera = Camera3D.new()
	camera.position.y = 1.55
	camera.current = true
	camera.fov = 82.0
	player.add_child(camera)
	_build_weapon()
	add_child(player)


func _build_weapon() -> void:
	# Classic M16A1-style rifle built from separate low-poly 3D parts.
	weapon_root = Node3D.new()
	weapon_root.name = "Classic_M16A1"
	weapon_root.position = Vector3(0.38, -0.34, -0.60)
	weapon_root.rotation_degrees = Vector3(-1.5, -1.0, 0.0)
	camera.add_child(weapon_root)

	var metal := Color(0.105, 0.12, 0.115)
	var dark_metal := Color(0.055, 0.065, 0.062)
	var black_polymer := Color(0.075, 0.082, 0.074)
	var olive_polymer := Color(0.22, 0.205, 0.145)

	# Upper/lower receiver and distinctive carry-handle upper profile.
	_weapon_box("LowerReceiver", Vector3(0, 0, 0.015), Vector3(0.17, 0.17, 0.36), metal)
	_weapon_box("UpperReceiver", Vector3(0, 0.075, -0.015), Vector3(0.165, 0.075, 0.39), metal)
	_weapon_box("CarryHandleBaseLeft", Vector3(-0.052, 0.19, 0.015), Vector3(0.035, 0.16, 0.34), metal)
	_weapon_box("CarryHandleBaseRight", Vector3(0.052, 0.19, 0.015), Vector3(0.035, 0.16, 0.34), metal)
	_weapon_box("CarryHandleBridge", Vector3(0, 0.265, 0.015), Vector3(0.14, 0.045, 0.34), metal)
	_weapon_box("CarryHandleTopRail", Vector3(0, 0.292, -0.01), Vector3(0.105, 0.018, 0.22), dark_metal)
	_weapon_box("RearSightBlock", Vector3(0, 0.31, 0.115), Vector3(0.075, 0.055, 0.075), dark_metal)
	_weapon_cylinder("RearSightAperture", Vector3(0, 0.316, 0.12), 0.025, 0.012, dark_metal, true)

	# Fixed triangular-style stock and butt plate.
	_weapon_box("StockNeck", Vector3(0, 0.005, 0.255), Vector3(0.135, 0.13, 0.22), olive_polymer)
	_weapon_box("FixedStock", Vector3(0, -0.005, 0.43), Vector3(0.145, 0.17, 0.34), olive_polymer)
	_weapon_box("StockButtPlate", Vector3(0, -0.005, 0.605), Vector3(0.15, 0.18, 0.035), dark_metal)
	_weapon_box("StockSlingSwivel", Vector3(-0.078, -0.055, 0.48), Vector3(0.018, 0.07, 0.035), metal)

	# Ribbed handguard, long barrel and front sight assembly.
	_weapon_cylinder("Barrel", Vector3(0, 0.02, -0.59), 0.027, 0.82, dark_metal, false)
	_weapon_box("HandguardCore", Vector3(0, 0.015, -0.39), Vector3(0.145, 0.135, 0.43), olive_polymer)
	for i in range(9):
		var z := -0.57 + float(i) * 0.045
		_weapon_box("HandguardRib_%02d" % i, Vector3(0, 0.015, z), Vector3(0.151, 0.142, 0.012), Color(0.17, 0.16, 0.115))
	_weapon_box("FrontSightBase", Vector3(0, 0.13, -0.79), Vector3(0.105, 0.12, 0.085), metal)
	_weapon_box("FrontSightPost", Vector3(0, 0.225, -0.79), Vector3(0.018, 0.105, 0.018), dark_metal)
	_weapon_box("FrontSightProtectLeft", Vector3(-0.045, 0.205, -0.79), Vector3(0.018, 0.08, 0.025), metal)
	_weapon_box("FrontSightProtectRight", Vector3(0.045, 0.205, -0.79), Vector3(0.018, 0.08, 0.025), metal)
	_weapon_cylinder("FrontBarrelBand", Vector3(0, 0.02, -0.76), 0.04, 0.035, metal, false)
	_weapon_cylinder("FlashSuppressor", Vector3(0, 0.02, -1.025), 0.035, 0.12, dark_metal, false)
	_weapon_cylinder("MuzzleTip", Vector3(0, 0.02, -1.09), 0.024, 0.012, metal, false)

	# Magazine, pistol grip, trigger and trigger guard.
	_weapon_box("MagazineWell", Vector3(0, -0.13, 0.015), Vector3(0.12, 0.12, 0.16), metal)
	_weapon_box("20RoundMagazine", Vector3(0, -0.285, 0.035), Vector3(0.105, 0.24, 0.13), dark_metal)
	_weapon_box("MagazineFloorPlate", Vector3(0, -0.412, 0.035), Vector3(0.112, 0.025, 0.14), metal)
	_weapon_box("PistolGrip", Vector3(0, -0.205, 0.205), Vector3(0.115, 0.25, 0.12), olive_polymer)
	_weapon_box("GripBase", Vector3(0, -0.335, 0.205), Vector3(0.12, 0.025, 0.125), dark_metal)
	_weapon_box("Trigger", Vector3(0, -0.12, 0.175), Vector3(0.018, 0.095, 0.018), metal)
	_weapon_box("TriggerGuardBottom", Vector3(0, -0.205, 0.13), Vector3(0.105, 0.018, 0.12), metal)
	_weapon_box("TriggerGuardFront", Vector3(0, -0.16, 0.075), Vector3(0.105, 0.09, 0.018), metal)
	_weapon_box("ChargingHandle", Vector3(0, 0.13, 0.19), Vector3(0.08, 0.025, 0.08), dark_metal)
	_weapon_box("Selector", Vector3(0.09, 0.035, 0.055), Vector3(0.025, 0.045, 0.09), dark_metal)
	_weapon_box("EjectionPort", Vector3(0.088, 0.075, -0.075), Vector3(0.012, 0.045, 0.105), Color(0.025, 0.03, 0.03))

func _weapon_box(part_name: String, part_position: Vector3, part_size: Vector3, part_color: Color) -> void:
	var part := MeshInstance3D.new()
	part.name = part_name
	var mesh := BoxMesh.new()
	mesh.size = part_size
	part.mesh = mesh
	part.position = part_position
	var material := StandardMaterial3D.new()
	material.albedo_color = part_color
	material.metallic = 0.48 if part_color == Color(0.105, 0.12, 0.115) or part_color == Color(0.055, 0.065, 0.062) else 0.08
	material.roughness = 0.68
	part.material_override = material
	weapon_root.add_child(part)

func _weapon_cylinder(part_name: String, part_position: Vector3, radius: float, length: float, part_color: Color, vertical: bool) -> void:
	var part := MeshInstance3D.new()
	part.name = part_name
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = length
	mesh.radial_segments = 16
	part.mesh = mesh
	part.position = part_position
	if not vertical:
		part.rotation.x = deg_to_rad(90.0)
	var material := StandardMaterial3D.new()
	material.albedo_color = part_color
	material.metallic = 0.62
	material.roughness = 0.48
	part.material_override = material
	weapon_root.add_child(part)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(root)

	hud_label = Label.new()
	hud_label.position = Vector2(18, 14)
	hud_label.add_theme_font_size_override("font_size", 19)
	hud_label.add_theme_color_override("font_color", Color(0.92, 0.91, 0.83))
	root.add_child(hud_label)

	health_label = Label.new()
	health_label.position = Vector2(18, 43)
	health_label.add_theme_font_size_override("font_size", 18)
	health_label.add_theme_color_override("font_color", Color(0.45, 0.95, 0.55))
	root.add_child(health_label)

	ammo_label = Label.new()
	ammo_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	ammo_label.position = Vector2(-190, 15)
	ammo_label.size = Vector2(175, 32)
	ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ammo_label.add_theme_font_size_override("font_size", 21)
	ammo_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.48))
	root.add_child(ammo_label)

	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-12, -22)
	crosshair.add_theme_font_size_override("font_size", 34)
	crosshair.add_theme_color_override("font_color", Color(1, 0.88, 0.55))
	root.add_child(crosshair)

	var help := Label.new()
	help.text = "LEFT: MOVE     RIGHT: LOOK"
	help.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	help.position = Vector2(20, -42)
	help.add_theme_font_size_override("font_size", 15)
	help.add_theme_color_override("font_color", Color(0.82, 0.83, 0.78))
	root.add_child(help)

	message_label = Label.new()
	message_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	message_label.position = Vector2(-170, 62)
	message_label.size = Vector2(340, 34)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 19)
	message_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.35))
	root.add_child(message_label)

	var fire_button := Button.new()
	fire_button.text = "FIRE"
	fire_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	fire_button.position = Vector2(-142, -105)
	fire_button.size = Vector2(112, 68)
	fire_button.add_theme_font_size_override("font_size", 22)
	fire_button.button_down.connect(_start_firing)
	fire_button.button_up.connect(_stop_firing)
	root.add_child(fire_button)

	var jump_button := Button.new()
	jump_button.text = "JUMP"
	jump_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	jump_button.position = Vector2(-142, -188)
	jump_button.size = Vector2(112, 58)
	jump_button.add_theme_font_size_override("font_size", 18)
	jump_button.pressed.connect(_jump)
	root.add_child(jump_button)

	var reload_button := Button.new()
	reload_button.text = "RELOAD"
	reload_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	reload_button.position = Vector2(-270, -93)
	reload_button.size = Vector2(112, 54)
	reload_button.add_theme_font_size_override("font_size", 17)
	reload_button.pressed.connect(_reload)
	root.add_child(reload_button)

	var orientation_button := Button.new()
	orientation_button.text = "ROTATE SCREEN"
	orientation_button.position = Vector2(18, 78)
	orientation_button.size = Vector2(170, 48)
	orientation_button.add_theme_font_size_override("font_size", 15)
	orientation_button.pressed.connect(_toggle_orientation)
	root.add_child(orientation_button)

func _process(delta: float) -> void:
	shot_cooldown = maxf(0.0, shot_cooldown - delta)
	if firing and shot_cooldown <= 0.0:
		_shoot()
	if weapon_root:
		weapon_recoil = move_toward(weapon_recoil, 0.0, delta * 0.9)
		weapon_root.position = Vector3(0.38, -0.31 + weapon_recoil * 0.35, -0.62 + weapon_recoil)
		weapon_root.rotation.x = -weapon_recoil * 0.55

func _physics_process(delta: float) -> void:
	var input_vector := Vector2.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		input_vector.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		input_vector.y += 1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		input_vector.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		input_vector.x += 1.0
	if touch_move.length() > 0.12:
		input_vector += touch_move
	input_vector = input_vector.limit_length(1.0)

	var direction := (player.transform.basis * Vector3(input_vector.x, 0, input_vector.y)).normalized()
	player.velocity.x = direction.x * PLAYER_SPEED
	player.velocity.z = direction.z * PLAYER_SPEED
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	elif player.velocity.y < 0:
		player.velocity.y = 0
	player.move_and_slide()

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_rotate_view(event.relative, MOUSE_SENSITIVITY)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_shoot()
	elif event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		elif event.keycode == KEY_R:
			_reload()
	elif event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.48 and move_touch_id == -1:
				move_touch_id = event.index
				touch_move = Vector2.ZERO
			elif look_touch_id == -1:
				look_touch_id = event.index
				last_look_position = event.position
		else:
			if event.index == move_touch_id:
				move_touch_id = -1
				touch_move = Vector2.ZERO
			if event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == move_touch_id:
			var center := Vector2(get_viewport().get_visible_rect().size.x * 0.22, get_viewport().get_visible_rect().size.y * 0.78)
			touch_move = ((event.position - center) / 90.0).limit_length(1.0)
		elif event.index == look_touch_id:
			var delta_position: Vector2 = event.position - last_look_position
			_rotate_view(delta_position, TOUCH_SENSITIVITY)
			last_look_position = event.position

func _rotate_view(relative: Vector2, sensitivity: float) -> void:
	player.rotate_y(-relative.x * sensitivity)
	pitch = clampf(pitch - relative.y * sensitivity, deg_to_rad(-82), deg_to_rad(82))
	camera.rotation.x = pitch

func _start_firing() -> void:
	firing = true
	_shoot()

func _stop_firing() -> void:
	firing = false

func _toggle_orientation() -> void:
	is_landscape = not is_landscape
	if is_landscape:
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_LANDSCAPE)
	else:
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_PORTRAIT)

func _jump() -> void:
	if player.is_on_floor():
		player.velocity.y = 7.5

func _shoot() -> void:
	if reloading or shot_cooldown > 0.0:
		return
	if ammo_in_magazine <= 0:
		message_label.text = "OUT OF AMMO - PRESS RELOAD"
		return
	ammo_in_magazine -= 1
	shot_cooldown = SHOT_INTERVAL
	weapon_recoil = 0.14
	var query := PhysicsRayQueryParameters3D.create(camera.global_position, camera.global_position - camera.global_transform.basis.z * 90.0)
	var result := get_world_3d().direct_space_state.intersect_ray(query)
	if result and result.collider is Node and result.collider.has_meta("is_target"):
		_damage_target(result.collider)
	_update_hud()

func _damage_target(target: Node) -> void:
	var remaining_health: int = int(target.get_meta("health")) - SHOT_DAMAGE
	target.set_meta("health", remaining_health)
	if remaining_health <= 0:
		target.queue_free()
		targets_destroyed += 1
		message_label.text = "TARGET DESTROYED!"
	else:
		message_label.text = "HIT! TARGET HP: %d" % remaining_health
		var mesh_instance := target.get_child(0) as MeshInstance3D
		var material := mesh_instance.material_override as StandardMaterial3D
		material.albedo_color = Color(0.95, 0.48, 0.08)

func _reload() -> void:
	if reloading or ammo_in_magazine == MAGAZINE_SIZE or reserve_ammo <= 0:
		return
	reloading = true
	message_label.text = "RELOADING..."
	_update_hud()
	await get_tree().create_timer(RELOAD_SECONDS).timeout
	var needed := MAGAZINE_SIZE - ammo_in_magazine
	var loaded := mini(needed, reserve_ammo)
	ammo_in_magazine += loaded
	reserve_ammo -= loaded
	reloading = false
	message_label.text = "READY"
	_update_hud()

func _update_hud() -> void:
	if hud_label:
		hud_label.text = "INDUSTRIAL STRIKE  |  TARGETS: %d/%d" % [targets_destroyed, total_targets]
	if health_label:
		health_label.text = "HEALTH: %d" % health
	if ammo_label:
		ammo_label.text = "AMMO: %02d / %02d" % [ammo_in_magazine, reserve_ammo]
