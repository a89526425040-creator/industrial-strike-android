extends Node3D

const PLAYER_SPEED := 7.0
const MOUSE_SENSITIVITY := 0.0022
const TOUCH_SENSITIVITY := 0.004
const GRAVITY := 22.0
const MAGAZINE_SIZE := 30
const START_RESERVE_AMMO := 90
const SHOT_DAMAGE := 34
const SHOT_INTERVAL := 0.075 # 800 rounds per minute
const RELOAD_SECONDS := 1.35

var player: CharacterBody3D
var camera: Camera3D
var pitch := 0.0
var touch_move := Vector2.ZERO
var look_touch_id := -1
var move_touch_id := -1
var last_look_position := Vector2.ZERO
var targets_destroyed := 0
var total_targets := 4
var ammo_in_magazine := MAGAZINE_SIZE
var reserve_ammo := START_RESERVE_AMMO
var health := 100
var shot_cooldown := 0.0
var reloading := false
var firing := false
var weapon_root: Node3D
var weapon_recoil := 0.0
var is_landscape := true
var hud_label: Label
var ammo_label: Label
var health_label: Label
var message_label: Label
var network_ip_input: LineEdit
var network_status_label: Label
var network_send_timer := 0.0
var remote_players: Dictionary = {}
var last_server_shot: Dictionary = {}
const NETWORK_PORT := 24567
const NETWORK_MAX_CLIENTS := 1 # two players total, including the host

func _ready() -> void:
	_build_world()
	_build_player()
	_build_hud()
	_update_hud()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_world() -> void:
	var world_env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.12, 0.18, 0.23)
	sky_material.sky_horizon_color = Color(0.55, 0.48, 0.37)
	sky_material.ground_bottom_color = Color(0.10, 0.11, 0.10)
	sky_material.ground_horizon_color = Color(0.28, 0.25, 0.20)
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.48, 0.52, 0.55)
	environment.ambient_light_energy = 0.55
	world_env.environment = environment
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)

	_add_box("Concrete yard", Vector3(0, -0.5, 0), Vector3(72, 1, 72), Color(0.24, 0.25, 0.23))
	_add_box("Main factory", Vector3(0, 5, -22), Vector3(34, 10, 12), Color(0.31, 0.32, 0.29))
	_add_box("Left warehouse", Vector3(-23, 4, -5), Vector3(12, 8, 28), Color(0.25, 0.29, 0.28))
	_add_box("Right warehouse", Vector3(23, 4, -7), Vector3(12, 8, 24), Color(0.32, 0.29, 0.24))
	_add_box("Loading bay", Vector3(0, 2.5, 9), Vector3(22, 5, 5), Color(0.30, 0.28, 0.23))

	for i in range(5):
		_add_box("Roof vent", Vector3(-12 + i * 6, 10.8, -22), Vector3(1.8, 1.6, 2.0), Color(0.19, 0.22, 0.22))
	for i in range(7):
		_add_box("Cargo container", Vector3(-13 + i * 4.3, 1.3, 2.0), Vector3(3.6, 2.6, 2.8), Color(0.36, 0.24 + float(i % 2) * 0.04, 0.13))
	_add_box("Concrete barrier", Vector3(0, 0.8, 16), Vector3(14, 1.6, 1.2), Color(0.48, 0.43, 0.32))
	_add_box("Pipe stack", Vector3(-17, 1.2, 17), Vector3(5, 2.4, 3), Color(0.20, 0.25, 0.25))
	_add_box("Generator", Vector3(16, 1.2, 17), Vector3(4, 2.4, 3), Color(0.20, 0.24, 0.19))

	for i in range(total_targets):
		_add_target(Vector3(-9 + i * 6, 1.15, -8), i)

func _add_box(label_text: String, position: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.name = label_text
	body.position = position
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.88
	mesh_instance.material_override = material
	body.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)

func _add_target(position: Vector3, target_id: int) -> void:
	var target := StaticBody3D.new()
	target.name = "PracticeTarget_%d" % target_id
	target.position = position
	target.add_to_group("practice_targets")
	target.set_meta("is_target", true)
	target.set_meta("target_id", target_id)
	target.set_meta("health", 100)
	var mesh_instance := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.48
	mesh.bottom_radius = 0.48
	mesh.height = 1.8
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.72, 0.18, 0.10)
	material.metallic = 0.15
	mesh_instance.material_override = material
	target.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 0.48
	shape.height = 1.8
	collision.shape = shape
	target.add_child(collision)
	add_child(target)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 1.2, 24)
	var capsule := CollisionShape3D.new()
	var capsule_shape := CapsuleShape3D.new()
	capsule_shape.radius = 0.38
	capsule_shape.height = 1.8
	capsule.shape = capsule_shape
	capsule.position.y = 0.9
	player.add_child(capsule)

	camera = Camera3D.new()
	camera.position.y = 1.55
	camera.current = true
	camera.fov = 82.0
	player.add_child(camera)
	_build_weapon()
	add_child(player)


func _build_weapon() -> void:
	weapon_root = Node3D.new()
	weapon_root.name = "Classic_M16A1_Imported"
	weapon_root.position = Vector3(0.38, -0.31, -0.62)
	weapon_root.rotation_degrees = Vector3(-1.5, -1.0, 0.0)
	camera.add_child(weapon_root)
	var weapon_scene := load("res://assets/weapons/m16a1_classic.glb") as PackedScene
	if weapon_scene:
		var weapon_model := weapon_scene.instantiate()
		weapon_root.add_child(weapon_model)
	else:
		push_error("Could not load classic M16A1 model")

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(root)

	hud_label = Label.new()
	hud_label.position = Vector2(18, 14)
	hud_label.add_theme_font_size_override("font_size", 19)
	hud_label.add_theme_color_override("font_color", Color(0.92, 0.91, 0.83))
	root.add_child(hud_label)

	health_label = Label.new()
	health_label.position = Vector2(18, 43)
	health_label.add_theme_font_size_override("font_size", 18)
	health_label.add_theme_color_override("font_color", Color(0.45, 0.95, 0.55))
	root.add_child(health_label)

	ammo_label = Label.new()
	ammo_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	ammo_label.position = Vector2(-190, 15)
	ammo_label.size = Vector2(175, 32)
	ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ammo_label.add_theme_font_size_override("font_size", 21)
	ammo_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.48))
	root.add_child(ammo_label)

	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-12, -22)
	crosshair.add_theme_font_size_override("font_size", 34)
	crosshair.add_theme_color_override("font_color", Color(1, 0.88, 0.55))
	root.add_child(crosshair)

	var help := Label.new()
	help.text = "LEFT: MOVE     RIGHT: LOOK"
	help.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	help.position = Vector2(20, -42)
	help.add_theme_font_size_override("font_size", 15)
	help.add_theme_color_override("font_color", Color(0.82, 0.83, 0.78))
	root.add_child(help)

	message_label = Label.new()
	message_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	message_label.position = Vector2(-170, 62)
	message_label.size = Vector2(340, 34)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 19)
	message_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.35))
	root.add_child(message_label)

	var fire_button := Button.new()
	fire_button.text = "FIRE"
	fire_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	fire_button.position = Vector2(-142, -105)
	fire_button.size = Vector2(112, 68)
	fire_button.add_theme_font_size_override("font_size", 22)
	fire_button.button_down.connect(_start_firing)
	fire_button.button_up.connect(_stop_firing)
	root.add_child(fire_button)

	var jump_button := Button.new()
	jump_button.text = "JUMP"
	jump_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	jump_button.position = Vector2(-142, -188)
	jump_button.size = Vector2(112, 58)
	jump_button.add_theme_font_size_override("font_size", 18)
	jump_button.pressed.connect(_jump)
	root.add_child(jump_button)

	var reload_button := Button.new()
	reload_button.text = "RELOAD"
	reload_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	reload_button.position = Vector2(-270, -93)
	reload_button.size = Vector2(112, 54)
	reload_button.add_theme_font_size_override("font_size", 17)
	reload_button.pressed.connect(_reload)
	root.add_child(reload_button)

	var orientation_button := Button.new()
	orientation_button.text = "ROTATE SCREEN"
	orientation_button.position = Vector2(18, 78)
	orientation_button.size = Vector2(170, 48)
	orientation_button.add_theme_font_size_override("font_size", 15)
	orientation_button.pressed.connect(_toggle_orientation)
	root.add_child(orientation_button)

	var net_title := Label.new()
	net_title.text = "2-PLAYER NETWORK TEST"
	net_title.position = Vector2(18, 140)
	net_title.add_theme_font_size_override("font_size", 16)
	net_title.add_theme_color_override("font_color", Color(0.85, 0.9, 1.0))
	root.add_child(net_title)

	network_ip_input = LineEdit.new()
	network_ip_input.position = Vector2(18, 166)
	network_ip_input.size = Vector2(190, 42)
	network_ip_input.placeholder_text = "Server IP address"
	network_ip_input.text = "127.0.0.1"
	network_ip_input.add_theme_font_size_override("font_size", 16)
	root.add_child(network_ip_input)

	var host_button := Button.new()
	host_button.text = "HOST"
	host_button.position = Vector2(18, 212)
	host_button.size = Vector2(88, 42)
	host_button.pressed.connect(_start_host)
	root.add_child(host_button)

	var join_button := Button.new()
	join_button.text = "JOIN"
	join_button.position = Vector2(112, 212)
	join_button.size = Vector2(88, 42)
	join_button.pressed.connect(_join_server)
	root.add_child(join_button)

	var disconnect_button := Button.new()
	disconnect_button.text = "DISCONNECT"
	disconnect_button.position = Vector2(18, 258)
	disconnect_button.size = Vector2(182, 38)
	disconnect_button.pressed.connect(_disconnect_network)
	root.add_child(disconnect_button)

	network_status_label = Label.new()
	network_status_label.text = "Offline mode"
	network_status_label.position = Vector2(18, 300)
	network_status_label.size = Vector2(320, 42)
	network_status_label.add_theme_font_size_override("font_size", 14)
	network_status_label.add_theme_color_override("font_color", Color(0.7, 0.9, 0.75))
	root.add_child(network_status_label)

func _process(delta: float) -> void:
	shot_cooldown = maxf(0.0, shot_cooldown - delta)
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		network_send_timer += delta
		if network_send_timer >= 0.05:
			network_send_timer = 0.0
			_send_network_state()
	if firing and shot_cooldown <= 0.0:
		_shoot()
	if weapon_root:
		weapon_recoil = move_toward(weapon_recoil, 0.0, delta * 0.9)
		weapon_root.position = Vector3(0.38, -0.31 + weapon_recoil * 0.35, -0.62 + weapon_recoil)
		weapon_root.rotation.x = -weapon_recoil * 0.55

func _physics_process(delta: float) -> void:
	var input_vector := Vector2.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		input_vector.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		input_vector.y += 1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		input_vector.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		input_vector.x += 1.0
	if touch_move.length() > 0.12:
		input_vector += touch_move
	input_vector = input_vector.limit_length(1.0)

	var direction := (player.transform.basis * Vector3(input_vector.x, 0, input_vector.y)).normalized()
	player.velocity.x = direction.x * PLAYER_SPEED
	player.velocity.z = direction.z * PLAYER_SPEED
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	elif player.velocity.y < 0:
		player.velocity.y = 0
	player.move_and_slide()

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_rotate_view(event.relative, MOUSE_SENSITIVITY)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_shoot()
	elif event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		elif event.keycode == KEY_R:
			_reload()
	elif event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.48 and move_touch_id == -1:
				move_touch_id = event.index
				touch_move = Vector2.ZERO
			elif look_touch_id == -1:
				look_touch_id = event.index
				last_look_position = event.position
		else:
			if event.index == move_touch_id:
				move_touch_id = -1
				touch_move = Vector2.ZERO
			if event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == move_touch_id:
			var center := Vector2(get_viewport().get_visible_rect().size.x * 0.22, get_viewport().get_visible_rect().size.y * 0.78)
			touch_move = ((event.position - center) / 90.0).limit_length(1.0)
		elif event.index == look_touch_id:
			var delta_position: Vector2 = event.position - last_look_position
			_rotate_view(delta_position, TOUCH_SENSITIVITY)
			last_look_position = event.position

func _rotate_view(relative: Vector2, sensitivity: float) -> void:
	player.rotate_y(-relative.x * sensitivity)
	pitch = clampf(pitch - relative.y * sensitivity, deg_to_rad(-82), deg_to_rad(82))
	camera.rotation.x = pitch

func _start_firing() -> void:
	firing = true
	_shoot()

func _stop_firing() -> void:
	firing = false

func _toggle_orientation() -> void:
	is_landscape = not is_landscape
	if is_landscape:
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_LANDSCAPE)
	else:
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_PORTRAIT)
	# Android recreates/resizes the rendering surface during rotation.
	# Let Android recreate the surface and Godot update the viewport dimensions.
	await get_tree().process_frame

func _jump() -> void:
	if player.is_on_floor():
		player.velocity.y = 7.5

func _shoot() -> void:
	if reloading or shot_cooldown > 0.0:
		return
	if ammo_in_magazine <= 0:
		message_label.text = "OUT OF AMMO - PRESS RELOAD"
		return
	ammo_in_magazine -= 1
	shot_cooldown = SHOT_INTERVAL
	weapon_recoil = 0.14
	var shot_origin := camera.global_position
	var shot_direction := -camera.global_transform.basis.z
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		if multiplayer.is_server():
			_server_process_shot(1, shot_origin, shot_direction)
		else:
			_rpc_request_shot.rpc_id(1, shot_origin, shot_direction)
	else:
		var query := PhysicsRayQueryParameters3D.create(shot_origin, shot_origin + shot_direction * 90.0)
		var result := get_world_3d().direct_space_state.intersect_ray(query)
		if result and result.collider is Node and result.collider.has_meta("is_target"):
			_damage_target(result.collider)
	_update_hud()

func _damage_target(target: Node) -> void:
	var remaining_health: int = int(target.get_meta("health")) - SHOT_DAMAGE
	target.set_meta("health", remaining_health)
	if remaining_health <= 0:
		target.queue_free()
		targets_destroyed += 1
		message_label.text = "TARGET DESTROYED!"
	else:
		message_label.text = "HIT! TARGET HP: %d" % remaining_health
		var mesh_instance := target.get_child(0) as MeshInstance3D
		var material := mesh_instance.material_override as StandardMaterial3D
		material.albedo_color = Color(0.95, 0.48, 0.08)

func _reload() -> void:
	if reloading or ammo_in_magazine == MAGAZINE_SIZE or reserve_ammo <= 0:
		return
	reloading = true
	message_label.text = "RELOADING..."
	_update_hud()
	await get_tree().create_timer(RELOAD_SECONDS).timeout
	var needed := MAGAZINE_SIZE - ammo_in_magazine
	var loaded := mini(needed, reserve_ammo)
	ammo_in_magazine += loaded
	reserve_ammo -= loaded
	reloading = false
	message_label.text = "READY"
	_update_hud()

func _update_hud() -> void:
	if hud_label:
		hud_label.text = "INDUSTRIAL STRIKE  |  TARGETS: %d/%d" % [targets_destroyed, total_targets]
	if health_label:
		health_label.text = "HEALTH: %d" % health
	if ammo_label:
		ammo_label.text = "AMMO: %02d / %02d" % [ammo_in_magazine, reserve_ammo]


# -------------------------------------------------------------------
# Two-player ENet prototype. One device hosts; one device joins.
# The host is the authority for target health and hit registration.
# -------------------------------------------------------------------

func _start_host() -> void:
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		_disconnect_network()
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_server(NETWORK_PORT, NETWORK_MAX_CLIENTS)
	if error != OK:
		_set_network_status("Host failed: error %d" % error)
		return
	multiplayer.multiplayer_peer = peer
	player.global_position = Vector3(-2.0, 1.2, 24.0)
	_set_network_status("HOSTING %s:%d (UDP) — waiting for player 2" % [_get_lan_ip(), NETWORK_PORT])

func _join_server() -> void:
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		_disconnect_network()
	var address := network_ip_input.text.strip_edges()
	if address.is_empty():
		_set_network_status("Enter the host IP address")
		return
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_client(address, NETWORK_PORT)
	if error != OK:
		_set_network_status("Join failed: error %d" % error)
		return
	multiplayer.multiplayer_peer = peer
	_set_network_status("Connecting to %s:%d..." % [address, NETWORK_PORT])

func _disconnect_network() -> void:
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	for peer_id in remote_players.keys():
		var avatar: Node = remote_players[peer_id]
		if is_instance_valid(avatar):
			avatar.queue_free()
	remote_players.clear()
	last_server_shot.clear()
	network_send_timer = 0.0
	_set_network_status("Offline mode")

func _get_lan_ip() -> String:
	for address in IP.get_local_addresses():
		if address.begins_with("192.168.") or address.begins_with("10.") or address.begins_with("172."):
			return address
	return "check device Wi-Fi IP"

func _set_network_status(value: String) -> void:
	if network_status_label:
		network_status_label.text = value

func _on_peer_connected(peer_id: int) -> void:
	_set_network_status("Player %d connected" % peer_id)

func _on_peer_disconnected(peer_id: int) -> void:
	if remote_players.has(peer_id):
		var avatar: Node = remote_players[peer_id]
		if is_instance_valid(avatar):
			avatar.queue_free()
		remote_players.erase(peer_id)
	last_server_shot.erase(peer_id)
	_set_network_status("Player %d disconnected" % peer_id)

func _on_connected_to_server() -> void:
	player.global_position = Vector3(2.0, 1.2, 24.0)
	_set_network_status("Connected — waiting for host state")

func _on_connection_failed() -> void:
	_disconnect_network()
	_set_network_status("Connection failed. Check IP, Wi-Fi and UDP port %d" % NETWORK_PORT)

func _on_server_disconnected() -> void:
	_disconnect_network()
	_set_network_status("Host disconnected")

func _send_network_state() -> void:
	if not is_instance_valid(player):
		return
	if multiplayer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	var pos := player.global_position
	var yaw := player.rotation.y
	if multiplayer.is_server():
		# The host's state is sent to the joining client.
		_rpc_receive_state.rpc(1, pos, yaw, pitch)
	else:
		_rpc_submit_state.rpc_id(1, pos, yaw, pitch)

@rpc("any_peer", "call_remote", "unreliable")
func _rpc_submit_state(pos: Vector3, yaw: float, view_pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id <= 1:
		return
	# Server relays the joining player's state to all connected clients.
	_rpc_receive_state.rpc(sender_id, pos, yaw, view_pitch)

@rpc("authority", "call_remote", "unreliable")
func _rpc_receive_state(peer_id: int, pos: Vector3, yaw: float, view_pitch: float) -> void:
	if peer_id == multiplayer.get_unique_id():
		return
	_ensure_remote_player(peer_id)
	var avatar: Node3D = remote_players[peer_id]
	avatar.global_position = avatar.global_position.lerp(pos, 0.72)
	avatar.rotation.y = yaw

func _ensure_remote_player(peer_id: int) -> void:
	if remote_players.has(peer_id) and is_instance_valid(remote_players[peer_id]):
		return
	var avatar := Node3D.new()
	avatar.name = "RemotePlayer_%d" % peer_id
	var body := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.38
	capsule.height = 1.65
	body.mesh = capsule
	body.position.y = 0.88
	var body_material := StandardMaterial3D.new()
	body_material.albedo_color = Color(0.12, 0.48, 0.82)
	body_material.roughness = 0.78
	body.material_override = body_material
	avatar.add_child(body)
	var head := MeshInstance3D.new()
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.22
	head_mesh.height = 0.44
	head.mesh = head_mesh
	head.position.y = 1.86
	head.material_override = body_material
	avatar.add_child(head)
	add_child(avatar)
	remote_players[peer_id] = avatar

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_shot(origin: Vector3, direction: Vector3) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id <= 1:
		return
	_server_process_shot(sender_id, origin, direction)

func _server_process_shot(shooter_id: int, origin: Vector3, direction: Vector3) -> void:
	var now := Time.get_ticks_msec()
	var previous := int(last_server_shot.get(shooter_id, 0))
	if now - previous < 55:
		return
	last_server_shot[shooter_id] = now
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction.normalized() * 90.0)
	var result := get_world_3d().direct_space_state.intersect_ray(query)
	if result and result.collider is Node and result.collider.has_meta("is_target"):
		var target := result.collider as Node
		var target_id := int(target.get_meta("target_id"))
		var remaining := int(target.get_meta("health")) - SHOT_DAMAGE
		var destroyed := remaining <= 0
		_apply_target_network_state(target_id, remaining, destroyed)
		_rpc_apply_target_network_state.rpc(target_id, remaining, destroyed)

func _apply_target_network_state(target_id: int, remaining_health: int, destroyed: bool) -> void:
	for target in get_tree().get_nodes_in_group("practice_targets"):
		if int(target.get_meta("target_id", -1)) != target_id:
			continue
		if destroyed:
			target.queue_free()
			targets_destroyed += 1
			if message_label:
				message_label.text = "TARGET DESTROYED!"
		else:
			target.set_meta("health", remaining_health)
			var mesh_instance := target.get_child(0) as MeshInstance3D
			var material := mesh_instance.material_override as StandardMaterial3D
			material.albedo_color = Color(0.95, 0.48, 0.08)
			if message_label:
				message_label.text = "HIT! TARGET HP: %d" % remaining_health
	_update_hud()

@rpc("authority", "call_remote", "reliable")
func _rpc_apply_target_network_state(target_id: int, remaining_health: int, destroyed: bool) -> void:
	_apply_target_network_state(target_id, remaining_health, destroyed)
