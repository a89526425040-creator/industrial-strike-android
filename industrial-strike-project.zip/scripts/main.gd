extends Node3D

const PLAYER_SPEED := 7.0
const MOUSE_SENSITIVITY := 0.0022
const TOUCH_SENSITIVITY := 0.004
const GRAVITY := 22.0

var player: CharacterBody3D
var camera: Camera3D
var pitch := 0.0
var touch_move := Vector2.ZERO
var look_touch_id := -1
var move_touch_id := -1
var last_look_position := Vector2.ZERO
var targets_hit := 0
var hud_label: Label

func _ready() -> void:
	_build_world()
	_build_player()
	_build_hud()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_world() -> void:
	var world_env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.12, 0.18, 0.23)
	sky_material.sky_horizon_color = Color(0.55, 0.48, 0.37)
	sky_material.ground_bottom_color = Color(0.10, 0.11, 0.10)
	sky_material.ground_horizon_color = Color(0.28, 0.25, 0.20)
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.48, 0.52, 0.55)
	environment.ambient_light_energy = 0.55
	world_env.environment = environment
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)

	_add_box("Concrete yard", Vector3(0, -0.5, 0), Vector3(72, 1, 72), Color(0.24, 0.25, 0.23))
	_add_box("Main factory", Vector3(0, 5, -22), Vector3(34, 10, 12), Color(0.31, 0.32, 0.29))
	_add_box("Left warehouse", Vector3(-23, 4, -5), Vector3(12, 8, 28), Color(0.25, 0.29, 0.28))
	_add_box("Right warehouse", Vector3(23, 4, -7), Vector3(12, 8, 24), Color(0.32, 0.29, 0.24))
	_add_box("Loading bay", Vector3(0, 2.5, 9), Vector3(22, 5, 5), Color(0.30, 0.28, 0.23))

	for i in range(5):
		_add_box("Roof vent", Vector3(-12 + i * 6, 10.8, -22), Vector3(1.8, 1.6, 2.0), Color(0.19, 0.22, 0.22))
	for i in range(7):
		_add_box("Cargo container", Vector3(-13 + i * 4.3, 1.3, 2.0), Vector3(3.6, 2.6, 2.8), Color(0.36, 0.24 + float(i % 2) * 0.04, 0.13))
	_add_box("Concrete barrier", Vector3(0, 0.8, 16), Vector3(14, 1.6, 1.2), Color(0.48, 0.43, 0.32))
	_add_box("Pipe stack", Vector3(-17, 1.2, 17), Vector3(5, 2.4, 3), Color(0.20, 0.25, 0.25))
	_add_box("Generator", Vector3(16, 1.2, 17), Vector3(4, 2.4, 3), Color(0.20, 0.24, 0.19))

	for i in range(4):
		_add_target(Vector3(-9 + i * 6, 1.15, -8))

func _add_box(label_text: String, position: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.name = label_text
	body.position = position
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.88
	mesh_instance.material_override = material
	body.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)

func _add_target(position: Vector3) -> void:
	var target := StaticBody3D.new()
	target.name = "PracticeTarget"
	target.position = position
	target.set_meta("is_target", true)
	var mesh_instance := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.48
	mesh.bottom_radius = 0.48
	mesh.height = 1.8
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.72, 0.18, 0.10)
	material.metallic = 0.15
	mesh_instance.material_override = material
	target.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 0.48
	shape.height = 1.8
	collision.shape = shape
	target.add_child(collision)
	add_child(target)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0, 1.2, 24)
	var capsule := CollisionShape3D.new()
	var capsule_shape := CapsuleShape3D.new()
	capsule_shape.radius = 0.38
	capsule_shape.height = 1.8
	capsule.shape = capsule_shape
	capsule.position.y = 0.9
	player.add_child(capsule)

	camera = Camera3D.new()
	camera.position.y = 1.55
	camera.current = true
	camera.fov = 82.0
	player.add_child(camera)
	add_child(player)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(root)

	hud_label = Label.new()
	hud_label.position = Vector2(18, 14)
	hud_label.add_theme_font_size_override("font_size", 20)
	hud_label.add_theme_color_override("font_color", Color(0.92, 0.91, 0.83))
	hud_label.text = "INDUSTRIAL STRIKE  |  TARGETS: 0/4"
	root.add_child(hud_label)

	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-12, -22)
	crosshair.add_theme_font_size_override("font_size", 34)
	crosshair.add_theme_color_override("font_color", Color(1, 0.88, 0.55))
	root.add_child(crosshair)

	var help := Label.new()
	help.text = "LEFT: MOVE     RIGHT: LOOK"
	help.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	help.position = Vector2(20, -42)
	help.add_theme_font_size_override("font_size", 15)
	help.add_theme_color_override("font_color", Color(0.82, 0.83, 0.78))
	root.add_child(help)

	var fire_button := Button.new()
	fire_button.text = "FIRE"
	fire_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	fire_button.position = Vector2(-142, -105)
	fire_button.size = Vector2(112, 68)
	fire_button.add_theme_font_size_override("font_size", 22)
	fire_button.pressed.connect(_shoot)
	root.add_child(fire_button)

	var jump_button := Button.new()
	jump_button.text = "JUMP"
	jump_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	jump_button.position = Vector2(-142, -188)
	jump_button.size = Vector2(112, 58)
	jump_button.add_theme_font_size_override("font_size", 18)
	jump_button.pressed.connect(_jump)
	root.add_child(jump_button)

func _physics_process(delta: float) -> void:
	var input_vector := Vector2.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		input_vector.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		input_vector.y += 1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		input_vector.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		input_vector.x += 1.0
	if touch_move.length() > 0.12:
		input_vector += touch_move
	input_vector = input_vector.limit_length(1.0)

	var direction := (player.transform.basis * Vector3(input_vector.x, 0, input_vector.y)).normalized()
	player.velocity.x = direction.x * PLAYER_SPEED
	player.velocity.z = direction.z * PLAYER_SPEED
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	elif player.velocity.y < 0:
		player.velocity.y = 0
	player.move_and_slide()

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_rotate_view(event.relative, MOUSE_SENSITIVITY)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_shoot()
	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.48 and move_touch_id == -1:
				move_touch_id = event.index
				touch_move = Vector2.ZERO
			elif look_touch_id == -1:
				look_touch_id = event.index
				last_look_position = event.position
		else:
			if event.index == move_touch_id:
				move_touch_id = -1
				touch_move = Vector2.ZERO
			if event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == move_touch_id:
			var center := Vector2(get_viewport().get_visible_rect().size.x * 0.22, get_viewport().get_visible_rect().size.y * 0.78)
			touch_move = ((event.position - center) / 90.0).limit_length(1.0)
		elif event.index == look_touch_id:
			var delta_position: Vector2 = event.position - last_look_position
			_rotate_view(delta_position, TOUCH_SENSITIVITY)
			last_look_position = event.position

func _rotate_view(relative: Vector2, sensitivity: float) -> void:
	player.rotate_y(-relative.x * sensitivity)
	pitch = clampf(pitch - relative.y * sensitivity, deg_to_rad(-82), deg_to_rad(82))
	camera.rotation.x = pitch

func _jump() -> void:
	if player.is_on_floor():
		player.velocity.y = 7.5

func _shoot() -> void:
	var query := PhysicsRayQueryParameters3D.create(camera.global_position, camera.global_position - camera.global_transform.basis.z * 90.0)
	var result := get_world_3d().direct_space_state.intersect_ray(query)
	if result and result.collider is Node and result.collider.has_meta("is_target"):
		result.collider.queue_free()
		targets_hit += 1
		hud_label.text = "INDUSTRIAL STRIKE  |  TARGETS: %d/4" % targets_hit
